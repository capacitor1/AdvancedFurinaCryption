﻿using System;
using System.Buffers;
using System.Diagnostics;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace ConsoleApp37;

public enum FurinaCryption
{
    Encrypt,
    Decrypt
}

internal struct AFCHeader
{
    public long AFCLen, RawLen, BlkNum, BlockLen, KeyLen;
    public Guid Guid;
}

internal struct BlkHeader
{
    public long PadLen, BlkID, BlkMD5;
}

public static class AdvancedFurinaCryption
{
    private static ReadOnlySpan<byte> Furina => "Furina\x7!"u8;

    public static void Dec(string inputPath, string outputPath)
    {
        using FileStream inputStream = new(inputPath, FileMode.Open, FileAccess.Read, FileShare.Read);
        using FileStream outputStream = new(outputPath, FileMode.OpenOrCreate, FileAccess.Write, FileShare.Read);
        //calculate
        AFCHeader afc = ReadAFCHeader(inputStream);
        BlkHeader blk;
        if (inputStream.Length != afc.AFCLen)
            throw new Exception("Incorrect file size.");
        long rawlen = afc.RawLen;
        outputStream.SetLength(rawlen);
        int blen = (int)afc.BlockLen;
        int klen = (int)afc.KeyLen;
        byte[] readBuffer = ArrayPool<byte>.Shared.Rent(blen);
        byte[] keyBuffer = ArrayPool<byte>.Shared.Rent(klen);
        Span<byte> readMem = readBuffer.AsSpan(0, blen);
        Span<byte> keyMem = keyBuffer.AsSpan(0, klen);
        for (int i = 0; i < afc.BlkNum; i++)
        {
            blk = ReadBlockHeader(inputStream);
            //read data
            inputStream.ReadExactly(keyMem);
            inputStream.ReadExactly(readMem);
            //write
            long pos = outputStream.Position = blk.BlkID * blen;
            int toWriteLen = (int)(pos + blen > rawlen ? (rawlen - pos) : blen);
            Span<byte> toWriteMem = readMem[..toWriteLen];
            XORCHNK(toWriteMem, keyMem);
            outputStream.Write(toWriteMem);
        }
        ArrayPool<byte>.Shared.Return(keyBuffer);
        ArrayPool<byte>.Shared.Return(readBuffer);
    }

    public static void Enc(string inputPath, string outputPath, int keyLength = 256, int blockLength = 1048576, bool isNoEnc = false)
    {
        //calculate
        FileInfo fileInfo = new(inputPath);
        long size = fileInfo.Length;
        int splitcount = (int)((size + blockLength - 1) / blockLength);
        long rawBlockSize = 32L + blockLength + keyLength;
        long afclen = 64 + (rawBlockSize * splitcount);
        //generate offset list
        long[] list = new long[splitcount];
        long a = 64;
        for (int i = 0; i < splitcount; i++)
        {
            list[i] = a;
            a += rawBlockSize;
        }
        Random.Shared.Shuffle(list);
        //write
        using FileStream inputStream = new(inputPath, FileMode.Open, FileAccess.Read, FileShare.Read);
        using FileStream outputStream = new(outputPath, FileMode.Create, FileAccess.Write, FileShare.Read);
        outputStream.SetLength(afclen);
        WriteAFCHeader(outputStream, size, blockLength, keyLength, Guid.NewGuid());
        byte[] readBuffer = ArrayPool<byte>.Shared.Rent(blockLength);
        byte[] keyBuffer = ArrayPool<byte>.Shared.Rent(keyLength);
        Span<byte> readMem = readBuffer.AsSpan(0, blockLength);
        Span<byte> keyMem = keyBuffer.AsSpan(0, keyLength);
        if (isNoEnc)
            keyMem.Clear();
        for (int i = 0; i < splitcount; i++)
        {
            if (!isNoEnc)
                RandomNumberGenerator.Fill(keyMem);
            outputStream.Position = list[i];
            WriteBlockHeader(outputStream, 0, i, 0);
            //enc
            outputStream.Write(keyMem);
            inputStream.ReadAtLeast(readMem, blockLength, false);
            if (!isNoEnc)
                XORCHNK(readMem, keyMem);
            outputStream.Write(readMem);
        }
    }

    private static AFCHeader ReadAFCHeader(Stream file)
    {
        AFCHeader header = new();
        Span<byte> span = stackalloc byte[16];
        file.ReadExactly(span);
        header.AFCLen = BitConverter.ToInt64(span[8..]);
        file.ReadExactly(span);
        header.RawLen = BitConverter.ToInt64(span);
        header.BlkNum = BitConverter.ToInt64(span[8..]);
        file.ReadExactly(span);
        header.BlockLen = BitConverter.ToInt64(span);
        header.KeyLen = BitConverter.ToInt64(span[8..]);
        file.ReadExactly(span);
        header.Guid = new(span);
        return header;
    }

    private static BlkHeader ReadBlockHeader(Stream file)
    {
        BlkHeader header = new();
        Span<byte> span = stackalloc byte[8];
        file.ReadExactly(span);
        file.ReadExactly(span);
        header.PadLen = BitConverter.ToInt64(span);
        file.ReadExactly(span);
        header.BlkID = BitConverter.ToInt64(span);
        file.ReadExactly(span);
        header.BlkMD5 = BitConverter.ToInt64(span);
        return header;

    }

    private static void WriteAFCHeader(Stream s, long rawlen, long blocklen, long keylen, Guid guid)//blocklen not contains block header
    {
        long blknum = (int)Math.Ceiling((double)rawlen / blocklen);
        long afclen = 64 + ((32 + blocklen + keylen) * blknum);
        Span<byte> span = stackalloc byte[64];
        Furina.CopyTo(span);
        BitConverter.TryWriteBytes(span[8..], afclen);
        BitConverter.TryWriteBytes(span[16..], rawlen);
        BitConverter.TryWriteBytes(span[24..], blknum);
        BitConverter.TryWriteBytes(span[32..], blocklen);
        BitConverter.TryWriteBytes(span[40..], keylen);
        guid.TryWriteBytes(span[48..]);
        s.Write(span);
    }

    private static void WriteBlockHeader(Stream s, long padlen, long blkid, long blkmd5)
    {
        Span<byte> span = stackalloc byte[32];
        Furina.CopyTo(span);
        BitConverter.TryWriteBytes(span[8..], padlen);
        BitConverter.TryWriteBytes(span[16..], blkid);
        BitConverter.TryWriteBytes(span[24..], blkmd5);
        s.Write(span);
    }

    private static void XORCHNK(Span<byte> chunk, ReadOnlySpan<byte> keys)
    {
        for (int i = 0, j = 0; i < chunk.Length; i++)
        {
            chunk[i] ^= keys[j];
            if (j >= keys.Length - 1)
                j = 0;
            else
                j++;
        }
    }
}
internal class Program
{
    private static void Main()
    {
        Console.InputEncoding = Encoding.UTF8;
        Console.OutputEncoding = Encoding.UTF8;
        string a = Console.ReadLine().AsSpan().Trim().Trim('"').ToString();
        string b = Console.ReadLine().AsSpan().Trim().Trim('"').ToString();
        string c = Console.ReadLine().AsSpan().Trim().Trim('"').ToString();
        Stopwatch sw = new();
        {
            sw.Restart();
            AdvancedFurinaCryption.Enc(a, b);
            sw.Stop();
            Console.WriteLine($"ENC: {sw.Elapsed}");
        }
        {
            sw.Restart();
            AdvancedFurinaCryption.Dec(b, c);
            sw.Stop();
            Console.WriteLine($"DEC: {sw.Elapsed}");
        }
        {
            sw.Restart();
            AdvancedFurinaCryption.Enc(a, b);
            sw.Stop();
            Console.WriteLine($"ENC: {sw.Elapsed}");
        }
        {
            sw.Restart();
            AdvancedFurinaCryption.Dec(b, c);
            sw.Stop();
            Console.WriteLine($"DEC: {sw.Elapsed}");
        }
    }
}